using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class MTools : MonoBehaviour
{
    public static void CreateCircle(GameObject go, Vector3 Radius, int number = 100)
    {
        LineRenderer line = go.AddComponent<LineRenderer>();
        line.positionCount = number + 1;
        line.useWorldSpace = false;
        line.material = ResLoad.Instance.LoadAsset<Material>("HiMaterials/LineMaterial");
        line.SetWidth(0.1f, 0.1f);
        line.material.SetColor("_Color", Color.red);
        line.startColor = Color.red;
        line.endColor = Color.red;

        float angle = 0;
        for (int i = 0; i < number + 1; i++)
        {
            line.SetPosition(i, new Vector3(
                Mathf.Sin(Mathf.Deg2Rad * angle) * Radius.x,
                Mathf.Cos(Mathf.Deg2Rad * angle) * Radius.y,
                Mathf.Cos(Mathf.Deg2Rad * angle) * Radius.z)); //设置每个点的坐标
            angle += (360f / number);
        }
    }

    public static LineRenderer DrawLine(Transform tr, LineRenderer mline, Vector3 start, Vector3 end,
        Color color = default(Color), float width = 0.1f)
    {
        if (mline == null)
        {
            return DrawLine(tr, start, end, color, width);
        }

        mline.useWorldSpace = true;
        mline.SetVertexCount(2);
        mline.SetWidth(width, width);
        mline.material.SetColor("_Color", color);
        mline.startColor = color;
        mline.endColor = color;
        mline.SetPosition(0, start);
        mline.SetPosition(1, end);
        mline.useWorldSpace = false;
        return mline;
    }

    public static LineRenderer DrawLine(Transform tr, Vector3 start, Vector3 end, Color color = default(Color),
        float width = 0.1f)
    {
        GameObject go = new GameObject();
        go.name = "line";
        LineRenderer line = go.AddComponent<LineRenderer>();
        go.transform.SetParent(tr);
        line.useWorldSpace = true;
        line.material = ResLoad.Instance.LoadAsset<Material>("HiMaterials/LineMaterial");
        line.positionCount = 2;
        line.SetWidth(width, width);
        line.material.SetColor("_Color", color);
        line.startColor = color;
        line.endColor = color;
        line.SetPosition(0, start);
        line.SetPosition(1, end);
        line.useWorldSpace = false;
        return line;
    }

    // 检测是否点到UI
    public static bool IsPointerOverUIObject(Vector2 screenPosition)
    {
        //实例化点击事件
        PointerEventData eventDataCurrentPosition = new PointerEventData(EventSystem.current);
        //将点击位置的屏幕坐标赋值给点击事件
        eventDataCurrentPosition.position = new Vector2(screenPosition.x, screenPosition.y);
        List<RaycastResult> results = new List<RaycastResult>();
        //向点击处发射射线
        EventSystem.current.RaycastAll(eventDataCurrentPosition, results);
        return results.Count > 0;
    }

    // 得到鼠标的世界坐标
    public static Vector3 MouseWorldPosition(Vector3 target)
    {
        Vector3 targetScreenPoint = Camera.main.WorldToScreenPoint(target);
        //当前鼠标所在的屏幕坐标
        Vector3 curScreenPoint = new Vector3(Input.mousePosition.x, Input.mousePosition.y, targetScreenPoint.z);
        //把当前鼠标的屏幕坐标转换成世界坐标
        Vector3 curWorldPoint = Camera.main.ScreenToWorldPoint(curScreenPoint);
        return curWorldPoint;
    }
}