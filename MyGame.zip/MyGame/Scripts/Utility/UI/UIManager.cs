using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class UIManager : Single<UIManager>
{
    ///<summary>
    ///UI层级
    ///</summary>
    public enum Layer
    {
        Top,
        Mid,
        Bot,
    }
    ///<summary>
    ///UI预设体
    ///</summary>
    public string uiPrefabPath = "Prefabs/UI/";  

    ///<summary>
    ///UI
    ///</summary>
    public Transform UI{ get; }

    ///<summary>
    ///Canvas
    ///</summary>
    public Transform UIRoot{ get; }

    ///<summary>
    ///UI顶层
    ///</summary>
    public Transform UITop{ get; }
    ///<summary>
    ///UI中层
    ///</summary>
    public Transform UIMid{ get; }
    ///<summary>
    ///UI底层
    ///</summary>
    public Transform UIBot{ get; }

    ///<summary>
    ///UI画布
    ///</summary>
    public Canvas RootCanvas{ get; }
    
    public Camera UICamera{ get; }
    
    ///<summary>
    ///Canvas层的RectTransform
    ///</summary>
    public RectTransform RootRectTransform{get;}
    ///<summary>
    ///画布尺寸相关
    ///</summary>
    public CanvasScaler RootScaler{get;}

    ///<summary>
    ///半屏宽
    ///</summary>
    public float HalfScreenW => Screen.width*0.5f;
    ///<summary>
    ///半屏高
    ///</summary>
    public float HalfScreenH => Screen.height*0.5f;
    private Vector2 screenUI;
    ///<summary>
    ///半屏UI位置
    ///</summary>
    public Vector2 ScreenUI => screenUI;
    ///<summary>
    ///真机比率
    ///</summary>
    public float RealMachineRatio =>(float)Screen.height/Screen.width;
    ///<summary>
    ///预设比率
    ///</summary>
    public float PreatRatio => RootScaler.referenceResolution.y/RootScaler.referenceResolution.x;
    ///<summary>
    ///UI面板管理表
    ///</summary>
    Dictionary<string,UIBase> uiPanelList;
    private UIManager()
    {
        uiPanelList = new Dictionary<string, UIBase>();
        UI = ResLoad.Instance.LoadPrefab(uiPrefabPath+"UI").transform;
        UIRoot = UI.Find("Canvas");
        UITop = UIRoot.Find("Top");
        UIMid = UIRoot.Find("Mid");
        UIBot = UIRoot.Find("Bot");
        RootCanvas = UIRoot.GetComponent<Canvas>();
        RootRectTransform = UIRoot.GetComponent<RectTransform>();
        RootScaler = UIRoot.GetComponent<CanvasScaler>();
        UICamera = UI.Find("UICamera").GetComponent<Camera>();
        Object.DontDestroyOnLoad(UI.gameObject);
        screenUI = ScreenToUI(new Vector3(Screen.width,Screen.height));
    }
    ///<summary>
    ///屏幕坐标转换UI坐标
    ///</summary>
    public Vector2 ScreenToUI(Vector3 v3)
    {
        Vector2 v2 = Vector2.zero;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(RootRectTransform,v3,RootCanvas.worldCamera,out v2);
        return v2;
    }
    ///<summary>
    ///UI坐标转换屏幕坐标
    ///</summary>
    public Vector2 UIToScreen(Vector3 v3)
    {
        return UICamera.WorldToScreenPoint(v3);
    }
    ///<summary>
    ///是否有对应名字的面板
    ///</summary>
    bool isHavePanel(string PanelName)
    {
        return uiPanelList.ContainsKey(PanelName);
    }

    public T initPanel<T>(string PanelName,string PrefabName,UnityAction action=null,Layer layer=Layer.Mid)
        where T:UIBase
    {   
        UIBase panel;
        if(!isHavePanel(PanelName))
        {
            GameObject obj = ResLoad.Instance.LoadPrefab(uiPrefabPath+PrefabName);
            obj.name = PanelName;
            
            //设置层级
            RectTransform tr = obj.transform as RectTransform;
            switch(layer)
            {
                case Layer.Top:tr.SetParent(UITop);break;
                case Layer.Mid:tr.SetParent(UIMid);break;
                case Layer.Bot:tr.SetParent(UIBot);break;
            }
            tr.localPosition = Vector3.zero;
            tr.localScale =Vector3.one;
            tr.offsetMax = Vector2.zero;
            tr.offsetMin = Vector2.zero;
            panel = obj.GetComponent<T>() ?? obj.AddComponent<T>();
            uiPanelList.Add(PanelName,panel);
            panel.Init(action);
        }
        else
        {
            panel = uiPanelList[PanelName];
            panel.transform.SetAsLastSibling();
        }
        return panel as T;
    }
    public T ShowPanel<T>(string PanelName,string PrefabName,UnityAction action=null,Layer layer=Layer.Mid)
        where T:UIBase
    {
        UIBase panel;
        if(!isHavePanel(PanelName))
        {
            panel = initPanel<T>(PanelName,PrefabName,action,layer);
        }
        else
        {
            panel = uiPanelList[PanelName];
            if(panel != null)
            {
                panel.transform.SetAsLastSibling();
            }
            else
            {
                foreach(var p in uiPanelList)
                {
                    Debug.Log(p.Key);
                    Debug.Log(p.Value);
                }
                return null;
            }
        }
        panel.Show(action);
        return panel as T;
    }
    public void HidePanel(string PanelName)
    {
        if(isHavePanel(PanelName))
        {
            uiPanelList[PanelName].Hide();
        }
    }
    public void HideAllPanel()
    {
        Dictionary<string,UIBase>.Enumerator enumerator
            = uiPanelList.GetEnumerator();
        while(enumerator.MoveNext())
        {
            uiPanelList[enumerator.Current.Key].Hide();
        }
    }
    public void DestroyPanel(string PanelName)
    {
        if(uiPanelList.ContainsKey(PanelName))
        {
            uiPanelList[PanelName].Destory();
            uiPanelList.Remove(PanelName);
        }
    }
    public void DestroyAllPanel()
    {
        Dictionary<string,UIBase>.Enumerator enumerator
            = uiPanelList.GetEnumerator();
        while(enumerator.MoveNext())
        {
            uiPanelList[enumerator.Current.Key].Destory();
        }
        uiPanelList.Clear();
    }
    public T GetPanel<T>(string PanelName)
        where T:UIBase
    {
        if(isHavePanel(PanelName))
        {
            return uiPanelList[PanelName] as T;
        }
        return null;
    }
    public GameObject LoadUIPrefab(string PrefabName,Transform parent,string name =null)
    {
        GameObject obj = ResLoad.Instance.LoadPrefab(uiPrefabPath+PrefabName);
        obj.name = name != string.Empty ? name : PrefabName;
        RectTransform tr = obj.transform as RectTransform;
        var size = tr.sizeDelta;
        tr.SetParent(parent);   
        tr.localPosition = Vector3.zero;
        tr.localScale =Vector3.one;
        tr.offsetMax = Vector2.zero;
        tr.offsetMin = Vector2.zero;
        tr.sizeDelta = size;
        return obj;
    }
}
