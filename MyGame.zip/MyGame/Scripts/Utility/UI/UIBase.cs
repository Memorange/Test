using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using DG.Tweening;

public class UIBase : MonoBehaviour
{
    public enum ShowType
    {
        Normal = 0,
        Fade,
        Mask,
    }

    private Dictionary<string,GameObject> itemList;  
    private CanvasGroup group;

    protected void DefaultButton(string ConctrolName,UnityAction<BaseEventData> callback=null,EventTriggerType type = EventTriggerType.PointerClick)
    {
        if(callback != null)
        {
            AddEventTrigger(ConctrolName,type,callback);
        }
        AddEventTrigger(ConctrolName,EventTriggerType.PointerEnter,data=>{
            PointerEnterAnim(GetGameObject(ConctrolName).transform as RectTransform);
        });
        AddEventTrigger(ConctrolName,EventTriggerType.PointerExit,data=>{
            PointerExitAnim(GetGameObject(ConctrolName).transform as RectTransform);
        });
    }
    protected void PointerEnterAnim(RectTransform rectTransform,float endValue = 1.2f, float duration = 0.3f,
        Ease ease = Ease.OutSine)
    {
        rectTransform.DOKill();
        rectTransform.DOScale(endValue,duration).SetEase(ease);
        
    }
    protected void PointerExitAnim(RectTransform rectTransform,float endValue = 1f, float duration = 0.3f,
        Ease ease = Ease.OutSine)
    {
        rectTransform.DOKill();
        rectTransform.DOScale(endValue,duration).SetEase(ease);
        
    }
    public ShowType showType = ShowType.Normal;
    public virtual void Init(UnityAction action=null)
    {
        
        itemList = new Dictionary<string, GameObject>();
        List<Transform> list =  new List<Transform>();
        findChilds(transform,list);
        for(int i=0;i<list.Count;i++)
        {
            if(list[i].CompareTag("Event"))
            {
                EventTrigger ET = list[i].gameObject.AddComponent<EventTrigger>();
                if(ET.triggers.Count ==0 )
                {
                    ET.triggers = new List<EventTrigger.Entry>();
                }
                itemList.Add(list[i].name,list[i].gameObject);
            }
            else if(list[i].CompareTag("UIGO"))
            {
                itemList.Add(list[i].name,list[i].gameObject);
            }
        }
        group = gameObject.AddComponent<CanvasGroup>();
        action?.Invoke();
    }
    public void findChilds(Transform father,List<Transform> list)
    {
        if(father.childCount ==0)
            return;
        int len = father.childCount;
        for (int i = 0; i < len; i++)
        {
            list.Add(father.GetChild(i));
            findChilds(father.GetChild(i),list);
        }
    }

    public virtual void Show(UnityAction action=null)
    {
        gameObject.SetActive(true);
        switch(showType)
        {
            case ShowType.Normal:action?.Invoke();break;
            case ShowType.Fade:
            {
                if(group == null)
                {
                    group = gameObject.AddComponent<CanvasGroup>();
                }
                group.interactable = false;
                group.DOFade(0f,0f);
                group.DOFade(1f,1.5f).SetEase(Ease.OutExpo).OnComplete(()=>
                {
                    action?.Invoke();
                    group.interactable = true;
                });
            }
            break;
        }
    }   
    
    public virtual void Hide(UnityAction action=null)
    {
        switch(showType)
        {
            case ShowType.Normal:action?.Invoke();
            gameObject.SetActive(false);
            break;
            case ShowType.Fade:
            {
                if(group == null)
                {
                    group = gameObject.AddComponent<CanvasGroup>();
                }
                group.interactable = false;
                group.DOFade(0f,1.5f).SetEase(Ease.OutExpo).OnComplete(()=>
                {
                    action?.Invoke();
                    gameObject.SetActive(false);
                });
            }
            break;
        }
    }
    public virtual void Destory(UnityAction action=null)
    {

    }
    protected T GetControl<T>(string name) 
        where T:MonoBehaviour
    {
        if(!itemList.ContainsKey(name))
        {
            return null;
        }
        return itemList[name].GetComponent<T>();
    }

    public GameObject GetGameObject(string name)
    {
        if(!itemList.ContainsKey(name))
        {
            return null;
        }
        return itemList[name];
    }

    public void AddEventTrigger(string ConctrolName,EventTriggerType type,UnityAction<BaseEventData> callback)
    {
        if(!itemList.ContainsKey(ConctrolName))
        {
            return;
        }
        if(itemList[ConctrolName].gameObject.GetComponent<EventTrigger>() ==null)
        {
            itemList[ConctrolName].gameObject.AddComponent<EventTrigger>(); 
        }
        EventTrigger.Entry entry = new EventTrigger.Entry();
        entry.callback = new EventTrigger.TriggerEvent();
        entry.callback.AddListener(callback);
        entry.eventID = type;
        itemList[ConctrolName].GetComponent<EventTrigger>().triggers.Add(entry);
    }
}
