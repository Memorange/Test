﻿using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 对象池
/// </summary>
public class Chunk
{
    /// <summary>
    /// 池子容器
    /// </summary>
    List<Object> objectList;

    /// <summary>
    /// 初始化容器
    /// </summary>
    public Chunk()
    {
        objectList = new List<Object>();
    }
    /// <summary>
    /// 是否存在对象
    /// </summary>
    public bool IsHave => objectList.Count > 0;

    /// <summary>
    /// 从池子里取出对象
    /// </summary>
    /// <returns></returns>
    public Object GetObj()
    {
        // 取第一个
        Object obj = objectList[objectList.Count - 1];
        // 从池子中移除
        objectList.RemoveAt(objectList.Count - 1);
        return obj;
    }

    /// <summary>
    /// 回收对象
    /// </summary>
    public void RevertObj(Object obj)
    {
        //这里也是我加的！！！！！！！！！！！
        (obj as GameObject).transform.parent = null;
        (obj as GameObject).gameObject.SetActive(false);
        objectList.Add(obj);
    }
}