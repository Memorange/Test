using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// GameObject相关类拓展
/// </summary>
public static class GameObjectExt
{
    public static List<GameObject> GetAllChilds(this GameObject gameObject)
    {
        List<GameObject> list = new List<GameObject>();
        FindChild(gameObject, list);
        return list;
    }

    private static void FindChild(GameObject father, List<GameObject> list)
    {
        if (father.transform.childCount == 0)
            return;
        int len = father.transform.childCount;
        for (int i = 0; i < len; i++)
        {
            list.Add(father.transform.GetChild(i).gameObject);
            FindChild(father.transform.GetChild(i).gameObject, list);
        }
    }
}