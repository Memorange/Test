using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Transform相关类拓展
/// </summary>
public static class TransformExt
{
    public static void Test(this Transform transform)
    {
        Debug.Log("nice");
    }
    // 获取所有子物体
    public static Transform[] GetChilds(this Transform transform)
    {
        Transform[] transforms = new Transform[transform.childCount];
        int i = 0;
        foreach (Transform item in transform)
        {
            transforms[i++] = item;
        }
        return transforms;
    }

    // 获取所有子物体
    public static List<Transform> GetAllChilds(this Transform transform)
    {
        List<Transform> list = new List<Transform>();
        FindChild(transform, list);
        return list;
    }

    /// <summary>
    /// 得到所有子物体
    /// </summary>
    /// <param name="father"></param>
    /// <param name="list"></param>
    /// <returns></returns>
    private static void FindChild(Transform father, List<Transform> list)
    {
        if (father.childCount == 0)
            return;
        int len = father.childCount;
        for (int i = 0; i < len; i++)
        {
            list.Add(father.GetChild(i));
            FindChild(father.GetChild(i), list);
        }
    }

    // 获取包围盒8顶点
    public static List<Vector3> GetBound8Vertex(this Transform transform)
    {
        Bounds bounds = GetBounds(transform.gameObject, transform.childCount > 0);
        return GetBound8Vertex(bounds);
    }

    public static List<Vector3> GetBound8Vertex(Bounds bounds)
    {
        List<Vector3> vertex8List = new List<Vector3>();
        Vector3 max = bounds.max;
        Vector3 min = bounds.min;
        Vector3 top1 = max;
        Vector3 top2 = new Vector3(max.x, max.y, min.z);
        Vector3 top3 = new Vector3(min.x, max.y, min.z);
        Vector3 top4 = new Vector3(min.x, max.y, max.z);

        Vector3 down1 = new Vector3(max.x,min.y,max.z);
        Vector3 down2 = new Vector3(max.x, min.y, min.z);
        Vector3 down3 = new Vector3(min.x, min.y, min.z);
        Vector3 down4 = new Vector3(min.x, min.y, max.z);
        
        vertex8List.Add(top1);
        vertex8List.Add(top2);
        vertex8List.Add(top3);
        vertex8List.Add(top4);
        vertex8List.Add(down1);
        vertex8List.Add(down2);
        vertex8List.Add(down3);
        vertex8List.Add(down4);
        
        return vertex8List;
    }

    // 获取包围盒
    public static Bounds GetBounds(this Transform transform)
    {
        return GetBounds(transform.gameObject, transform.childCount > 0);
    }

    private static Bounds GetBounds(GameObject target, bool include_children = true)
    {
        Renderer[] mrs = target.gameObject.GetComponentsInChildren<Renderer>();
        Vector3 center = target.transform.position;
        Bounds bounds = new Bounds(center, Vector3.zero);
        if (include_children)
        {
            if (mrs.Length != 0)
            {
                foreach (Renderer mr in mrs)
                {
                    if(mr.gameObject.layer == LayerMask.NameToLayer("Decoration"))
                        continue;
                    bounds.Encapsulate(mr.bounds);
                }
            }
        }
        else
        {
            Renderer rend = target.GetComponentInChildren<Renderer>();
            if (rend)
            {
                bounds = rend.bounds;
            }
        }
        return bounds;
    }
}