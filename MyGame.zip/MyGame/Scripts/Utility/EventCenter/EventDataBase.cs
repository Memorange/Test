using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventDataBase
{
    
}
public class EventDataCamera : EventDataBase
{
    public bool isMove;
}

public class EventDataPlayerMove : EventDataBase
{
    public Vector2 move;
}

public enum EMouseInputState
{
    Down,
    Stay,
    Up
}
public enum EMouseInputKey
{
    Left,
    Mid,
    Right
}
public class EventDataMouseInput : EventDataBase
{
    public EMouseInputState state;
    public EMouseInputKey key;
    public Vector2 position;
}
public enum EanimType
{
    idle,
    walk,
    jump,
    attack,
    fireend,
    damage
}
public class EventdataPlayeranim : EventDataBase
{
    public float speed;
    public EanimType type;
}