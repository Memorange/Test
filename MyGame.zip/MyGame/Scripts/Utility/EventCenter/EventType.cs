using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public enum EventType
{
  PlayerMove = 10001,
    Mouseinput = 10002,
    HeroAttack = 10003,
    PlayerAnim = 10004,
    PlayerJump = 10005,
    RefreshBag = 10006,
    CloseCamera = 10007
}
