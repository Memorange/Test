using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventListener
{
    public object Listener { get; }
    public EventCallBack CallBack { get; }

    public EventListener(object listener, EventCallBack callback)
    {
        Listener = listener;
        CallBack = callback;
    }
}
