using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 事件中心回调
/// </summary>
public delegate void EventCallBack(EventDataBase data);
public class EventManager : Single<EventManager>
{
    /// <summary>
    /// 事件监听器字典
    /// </summary>
    Dictionary<EventType, List<EventListener>> eventListenerList = new Dictionary<EventType, List<EventListener>>();
    
    /// <summary>
    /// 注册事件
    /// </summary>
    /// <param name="eventType"></param>
    /// <param name="listener"></param>
    /// <param name="callBack"></param>
    public void Add(EventType eventType, object listener, EventCallBack callBack)
    {
        if (listener == null)
        {
            return;
        }
        AddEvent(eventType);
        eventListenerList[eventType].Add(new EventListener(listener, callBack));
    }

    private void AddEvent(EventType eventType)
    {
        if (!eventListenerList.ContainsKey(eventType))
        {
            eventListenerList.Add(eventType, new List<EventListener>());
        }
    }

    /// <summary>
    /// 发送事件
    /// </summary>
    /// <param name="eventType"></param>
    /// <param name="eventData"></param>
    public void SendEvent(EventType eventType, EventDataBase eventData)
    {
        if (eventListenerList.ContainsKey(eventType))
        {
            List<EventListener> listenerList = eventListenerList[eventType];
            for (int i = 0; i < listenerList.Count; i++)
            {
                listenerList[i].CallBack(eventData);
            }
        }
    }

    /// <summary>
    /// 删除事件指定的接收者
    /// </summary>
    /// <param name="eventType"></param>
    /// <param name="listener"></param>
    public void RemoveEventListener(EventType eventType, object listener)
    {
        List<EventListener> listenerList;
        if (eventListenerList.TryGetValue(eventType, out listenerList))
        {
            for (int i = 0; i < listenerList.Count; i++)
            {
                if (listenerList[i].Listener == listener)
                {
                    listenerList.RemoveAt(i);
                    return;
                }
            }
        }
    }

    /// <summary>
    /// 删除指定事件类型
    /// </summary>
    /// <param name="eventType"></param>
    public void RemoveEvent(EventType eventType)
    {
        if (eventListenerList.ContainsKey(eventType))
        {
            eventListenerList.Remove(eventType);
        }
    }

    public void Clear()
    {
        eventListenerList.Clear();
    }

}
