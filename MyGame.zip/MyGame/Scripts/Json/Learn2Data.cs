using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

public class Learn2Data : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        int a = 188;
        byte[] bytes = BitConverter.GetBytes(a);
        int b = BitConverter.ToInt32(bytes,0);
        bytes = Encoding.UTF8.GetBytes("啊哈哈");
        string str = Encoding.UTF8.GetString(bytes);
        // File.WriteAllBytes(Application.streamingAssetsPath+"/Test2data.yea",bytes);
        // string[] strarr = {"123","456"};
        // File.WriteAllLines(Application.streamingAssetsPath+"/Test2data.yea",strarr);
        // strarr = File.ReadAllLines(Application.streamingAssetsPath+"/Test2data.yea");
        // File.Copy(Application.streamingAssetsPath+"/Test2data.yea",Application.streamingAssetsPath+"/Test2data2.yea");
        // File.Replace(Application.streamingAssetsPath+"/Test2data.yea",Application.streamingAssetsPath+"/Test2data2.yea",Application.streamingAssetsPath+"/Test2data.yea");
        // File.Delete(Application.streamingAssetsPath+"/Test2data.yea");
        
        // FileStream fs = new FileStream(Application.streamingAssetsPath+"/Test2data.yea",FileMode.Create,FileAccess.ReadWrite);
        // fs = File.Create(Application.streamingAssetsPath+"/Test2data.yea");
        // File.Open(Application.streamingAssetsPath+"/Test2data.yea",FileMode.Create);
        // if(fs.CanWrite)
        // {
        //     fs.Write(bytes,0,bytes.Length);
        // }
        // fs.Flush();//写入之后要调用
        // fs.Close();
        // fs.Dispose();//缓存资源回收

        //写入
        FileStream fs = new FileStream(Application.streamingAssetsPath+"/Test2data.yea",FileMode.OpenOrCreate);//文件流
        BinaryWriter binaryWriter = new BinaryWriter(fs);//二进制写入

        binaryWriter.Write(bytes,0,bytes.Length);

        binaryWriter.Close();
        fs.Close();

        byte[] bBuffer;

        //读取
        fs = new FileStream(Application.streamingAssetsPath+"/Test2data.yea",FileMode.OpenOrCreate);//文件流
        BinaryReader binaryReader = new BinaryReader(fs);

        bBuffer = new byte[fs.Length];
        binaryReader.Read(bBuffer,0,(int)bBuffer.Length);

        binaryReader.Close();
        fs.Close();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
