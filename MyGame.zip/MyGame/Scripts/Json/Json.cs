using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;
using LitJson;

[Serializable]
public class TestData
{
    public int id;
    public string info;
    public float coin; 
    public double dou;
    public bool isShow;
    public int[] array;
}
[Serializable]
public class TestJsonData
{
    public string name;
    public List<TestData> dataList;
    public Dictionary<string,string> dic;
    public TestData data;
    [SerializeField]
    private int pri;
    [SerializeField]
    protected int pro;
    public TestJsonData()
    {

    }
    public TestJsonData(int a,int b)
    {
          pri=a;
          pro=b;
    }
}
public class Json : MonoBehaviour
{
    //数字型short,int，long,float,double
    //字符串："abc","你好"
    //布尔：true false
    //空类型:null
    //数组【列表】：[1,2,3]
    //对象【对象】：{"key1":"value","key2":null,"key3":{"key4":"01"}}


    // Start is called before the first frame update
    void Start()
    {
       //Application
       
       /*
       pc:
       Application.dataPath
            D:/MR/RE(3dRPG)/Assets
       Application.streamingAssetsPath
            D:/MR/RE(3dRPG)/Assets/StreamingAssets
       Application.persistentDataPath
            C:/Users/MR/AppData/LocalLow/DefaultCompany/春暖花开
       Application.temporaryCachePath
            C:/Users/MR/AppData/Local/Temp/DefaultCompany/春暖花开
       */
       Debug.Log(Application.dataPath);
       Debug.Log(Application.streamingAssetsPath);
       Debug.Log(Application.persistentDataPath);
       Debug.Log(Application.temporaryCachePath);
       
       // 文件写入
       File.WriteAllText(Application.persistentDataPath+"/test.json","我们新建的json文件");
       // 文件读取
       string str = File.ReadAllText(Application.persistentDataPath+"/test.json");
       Debug.Log(str);
       str = File.ReadAllText(Application.streamingAssetsPath+"/LearnJson.json");
       Debug.Log(str);
       var test = new TestJsonData(1,2);
       test.data =null;
       test.name ="haha";
       test.dataList = new List<TestData>()
       {
            new TestData()
            {
                id=1,
                info = "你好呀",
                coin=2.5f,
                dou =3.8,
                isShow = true,
                array = new[]{1,3,5,7}
            },
            new TestData()
            {
                id=2,
                info = "你好呀2",
                coin=4.5f,
                dou =4.8,
                isShow = false,
                array = new[]{2,3,4,6}
            }
       };
       test.dic = new Dictionary<string, string>()
       {
            {"1","haha"},
            {"2","hehe"}
       };
       DataManager.Instance.SaveData(test,"Json","testMgr",JsonType.JsonUtility);
       // JsonUtility
     //   str = JsonUtility.ToJson(test);
     //   File.WriteAllText(Application.persistentDataPath+"/test.json",str);
     //   Debug.Log(str);
     //   str = File.ReadAllText(Application.persistentDataPath+"/test.json");
     //   TestJsonData jsondata = JsonUtility.FromJson<TestJsonData>(str);
       // LitJson
     //   List<TestJsonData> listdata = new List<TestJsonData>(){test,test,test};
     //   str = JsonMapper.ToJson(listdata);
     //   Debug.Log(str);
     //   File.WriteAllText(Application.persistentDataPath+"/LitJsontest.json",str);
     //   string path = Application.persistentDataPath+"/LitJsontest.json";
     //   str = File.ReadAllText(path);
     //   List<TestJsonData> data = JsonMapper.ToObject<List<TestJsonData>>(str);
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
