using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeroMove : MonoBehaviour
{
    private Rigidbody rb;
    private Vector2 movementInput;
    private bool isRunning;
    private Vector3 movement;
    private float speed=3;
    private float turnsSpeed = 30;
    private Quaternion targetRotation;
    public GameObject Biu;
    public Animator anim;
    public float jumpGravity = -19.8f;
    public float jumpForce = 8;
    private void Start() {
        rb = GetComponent<Rigidbody>();
        anim = GetComponent<Animator>();
        EventManager.Instance.Add(EventType.PlayerMove,this,data =>{
            var eventData = data as EventDataPlayerMove;
            movementInput = eventData.move;
            
        });
        EventManager.Instance.Add(EventType.PlayerJump,this,data=>{
            Physics.gravity = new Vector3(Physics.gravity.x,jumpGravity,Physics.gravity.z);
            rb.velocity = new Vector3(rb.velocity.x,jumpForce/rb.mass,rb.velocity.z);
            EventManager.Instance.SendEvent(EventType.PlayerAnim,new EventdataPlayeranim{
                type = EanimType.jump
            });
        });
    }
    private void FixedUpdate() {
        movementInput = new Vector2(Input.GetAxis("Horizontal"),Input.GetAxis("Vertical"));
        movement.Set(movementInput.x,0,movementInput.y);
        movement.Normalize();
        
        bool Horizontalinput = !Mathf.Approximately(movementInput.x,0);
        bool Verticalinput = !Mathf.Approximately(movementInput.y,0);
        if(isRunning && !(Horizontalinput || Verticalinput))
        {
            
            EventManager.Instance.SendEvent(EventType.PlayerAnim,new EventdataPlayeranim
            {
                speed = 0,
                type = EanimType.walk
            });
            
        }

        isRunning = Horizontalinput || Verticalinput;
        if(isRunning){
            movement = Quaternion.Euler(0,Camera.main.transform.eulerAngles.y,0) * movement;
            EventManager.Instance.SendEvent(EventType.PlayerAnim,new EventdataPlayeranim{
                type = EanimType.walk,
                speed = movement.sqrMagnitude
            });

        }
        Vector3 lookforward = Vector3.RotateTowards(transform.forward,movement,turnsSpeed*Time.fixedDeltaTime,0);
        targetRotation = Quaternion.LookRotation(lookforward);

        rb.MovePosition(rb.position+movement*speed*Time.fixedDeltaTime);
        rb.MoveRotation(targetRotation);

        
    }
}
