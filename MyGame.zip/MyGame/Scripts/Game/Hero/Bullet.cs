using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;
using DG.Tweening;

public class Bullet : MonoBehaviour
{
    public float Speed =3;
    public float att;
    public float survivalTime = 1;
    public ObjectPool<GameObject> bulletPool;
    public Tween tween;
    // Start is called before the first frame update
    void OnEnable()
    {
        float timer = 0;
        //tween计时器//经过survivalTime ，timer 从0到1
        tween = DOTween.To(()=>timer, x=>timer = x,1,survivalTime);
        tween.OnComplete(()=>
        {
            bulletPool.Release(gameObject);
        });
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.forward * Time.deltaTime*Speed);
    }

    private void OnTriggerEnter(Collider other) {
        if(other.GetComponent<EnemyInfo>())
        {
            Debug.Log("碰到敌人");
            EnemyInfo enemy = other.gameObject.GetComponent<EnemyInfo>();
            enemy.Injured(att);
            tween.Kill(true);
            
        }
    }
}
