using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

public class HeroAttack : MonoBehaviour
{
    public Transform bulletTR;
    private ObjectPool<GameObject> bulletPool;
    // Start is called before the first frame update
    void Start()
    {
        EventManager.Instance.Add(EventType.HeroAttack,this,data=>
        {
            Attack();
        });
        bulletPool = new ObjectPool<GameObject>(
            ()=>
            {
                var bullet = ResLoad.Instance.LoadPrefab("Prefabs/Bullet");
                bullet.GetComponent<Bullet>().bulletPool =bulletPool;
                return bullet;
            },
            go=>
            {
                go.SetActive(true);
                go.transform.position = bulletTR.position;
                go.transform.rotation = transform.rotation;
            },
            go=>
            {
                go.SetActive(false);
            },
            go=>{Destroy(go);}
        );
    }
    private void Attack()
    {
        var bullet = bulletPool.Get();
    }
}

