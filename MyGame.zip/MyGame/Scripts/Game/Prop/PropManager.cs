using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

public enum PropType
{

}
public class PropManager : Single<PropManager>
{
    private ObjectPool<GameObject> PropPool;
    private PropManager()
    {
        PropPool = new ObjectPool<GameObject>(
            ()=>
            {
                var prop = ResLoad.Instance.LoadPrefab("Prefabs/Prop/"+Random.Range(0,2));
                return prop;
            },
            go=>
            {
                go.SetActive(true);
            },
            go=>
            {
                go.SetActive(false);
            },
            go=>{GameObject.Destroy(go);}
        );
    }
    //生成道具
    public void Create(Transform transform)
    {
        var go = PropPool.Get();
        go.transform.position = transform.position;
    }
    //销毁道具
   public void Remove(GameObject prop)
   {
        PropPool.Release(prop);
   }
}
