using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickProp : MonoBehaviour
{
    private void OnCollisionEnter(Collision other)
    {
        var prop = other.gameObject.GetComponent<Prop>();
        if(prop)
        {
            Debug.Log("获取道具");
            //存储数据
            if(MyGameManager.Instance.playerInfo == null)
            {
                MyGameManager.Instance.playerInfo = DataManager.Instance.LoadPlayerData();
            }
            MyGameManager.Instance.playerInfo.BagChangeItem(prop.id,prop.num);
            EventManager.Instance.SendEvent(EventType.RefreshBag,null);
            //回收道具 
            PropManager.Instance.Remove(prop.gameObject);
        }    
    }
}