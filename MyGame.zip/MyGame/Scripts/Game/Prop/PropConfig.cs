using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]

public enum PropTypes
{
    type1,
    type2,
    type3
}

[Serializable]
public struct PropData
{
    public int id;
    public string info;
    public int coin; 
    public PropTypes type;
    public string name;
    public string iconPath;
    public Sprite icon;
}



[CreateAssetMenu(fileName ="PropConfig",menuName ="Yea/PropConfig",order =1)]
public class PropConfig : ScriptableObject
{
    public List<PropData> propList;
}
