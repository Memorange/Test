using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum EEnemyType
{
    type1,
    type2,
}

public class EnemyInfo : MonoBehaviour
{
    
    private float hp = 100;
    public float maxHp;
    public float att;
    public float def;
    public EEnemyType type;
    public Slider lifebar;

    public void OnEnable()
    {
        //添加血条
        lifebar = LifebarManager.Instance.Create(0,maxHp,hp,transform);
    }

    public void SetHp(float sHp)
    {
        hp = sHp;
        LifebarManager.Instance.Refresh(lifebar,hp);
    }
    //受伤
    public void Injured(float att)
    {
        float rAtt = Mathf.Max(1,att - def);
        SetHp(Mathf.Max(0 , hp - rAtt));
        if(hp == 0)
        {
            Die();
        }
    }
    public void Die()
    {
        //销毁血条
        LifebarManager.Instance.Remove(lifebar);
        //播放死亡动画
        //销毁敌人
        Destroy(gameObject);
        //发送道具掉落事件 
        Debug.Log("敌人掉落道具");
        PropManager.Instance.Create(transform);
    } 
}
