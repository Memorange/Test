using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInfo : MonoBehaviour
{
   public int level;
   public int exp;
   public int coin;
   public string name;
   //背包   //KEY值为ID，value为数量
   public Dictionary<int,int> bag = new Dictionary<int, int>();
   //现有英雄
   //public List<> Hero;
   //目前使用英雄


   public HeroInfo nowHero;
   public void BagChangeItem(int id,int num)
   {
      
      if(bag.ContainsKey(id))
      {
         bag[id] += num;
         if(bag[id]<1)
         {
            bag.Remove(id);
         }
      }
      else
      {
         bag.Add(id,num);
      }
      DataManager.Instance.SaveBagData(bag);
   }
}
