using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

using LitJson;

public enum JsonType
{
    JsonUtility,
    LitJson
}

public class DataManager : Single<DataManager>
{
    

    public void SaveData(object data,string file,string fileName,JsonType jsonType = JsonType.LitJson)
    {
        string path = Application.persistentDataPath+"/"+file+"/"+fileName+".json";
        string str = "";
        if(!File.Exists(path))
        {
            Directory.CreateDirectory(Application.persistentDataPath+"/"+file+"/");
            FileStream fs = File.Create(path);
            fs.Close();
            fs.Dispose();//清缓存
        }
        switch(jsonType)
        {
            case JsonType.JsonUtility:
                str = JsonUtility.ToJson(data);
                break;
            case JsonType.LitJson:
                str = JsonMapper.ToJson(data);
                break;
        }
        File.WriteAllText(path,str);
    }
    public T LoadData<T>(string fileName,JsonType jsonType = JsonType.LitJson)
        where T : new()
    {
        string path = Application.streamingAssetsPath+"/"+fileName+".json";
        if(!File.Exists(path))
        {
            path = Application.persistentDataPath+"/"+fileName+".json";
        }
        if(!File.Exists(path))
        {
            return default;
        }
        string str = "";
        str = File.ReadAllText(path);
        T data = default(T);
        switch(jsonType)
        {
            case JsonType.JsonUtility:
                data = JsonUtility.FromJson<T>(str);
                break;
            case JsonType.LitJson:
                data = JsonMapper.ToObject<T>(str);
                break;
        }
        return data;
    }

    public PlayerInfo LoadPlayerData()
    {
        PlayerInfo data =new PlayerInfo();
        data.coin = PlayerPrefs.GetInt("Coin");
        data.bag = new Dictionary<int, int>();
        int BagCount = PlayerPrefs.GetInt("BagCount");
        for (int i = 0; i < BagCount; i++)
        {
            data.bag.Add(PlayerPrefs.GetInt("BagId"+i),PlayerPrefs.GetInt("BagItemNum"+i));
            
        }
        return data;

    }
    public void SaveCoin(int num)
    {
        PlayerPrefs.SetInt("Coin",num);
    }

    public void SaveBagData(Dictionary<int,int> bagdata)
    {
        PlayerPrefs.SetInt("BagCount",bagdata.Count);
        int index = 0;
        foreach (var data in bagdata)
        {
            PlayerPrefs.SetInt("BagId"+index,data.Key);
            PlayerPrefs.SetInt("BagItemNum"+index,data.Value);
            index++;
        }
    }
}
