using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EHeroType
{
    type1,
    type2,
}
public class HeroInfo : MonoBehaviour
{
    public float hp;
    public float maxHp;
    public float att;
    public float def;
    public EHeroType type;

    public void SetHp(float sHp=-1)
    {
        if(sHp < 0)
        {
            hp = maxHp;
            return;
        }
        hp = sHp;
    }
    //受伤
    public void Injured(float att)
    {
        float rAtt = Mathf.Max(1,att - def);
        hp = Mathf.Max(0 , hp - rAtt);
        if(hp == 0)
        {
            Die();
        }
    }
    public void Die()
    {
        //播放死亡动画
        //回收英雄
    }
}
