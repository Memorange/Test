using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;
using UnityEngine.UI;

public class LifebarManager : Single<LifebarManager>
{
    private ObjectPool<GameObject> LifebarPool;

    public LifebarManager()
    {
        LifebarPool = new ObjectPool<GameObject>(
            ()=>
            {
                var Lifebar = UIManager.Instance.LoadUIPrefab("LifebarSlider",UIManager.Instance.UIBot,"Hp");
                return Lifebar;
            },
            go=>
            {
                go.SetActive(true);
            },
            go=>
            {
                go.SetActive(false);
            },
            go=>{GameObject.Destroy(go);}
        );
        
    }
    //创建血条
    public Slider Create(float min,float max,float value,Transform transform)
    {   
        var slider = LifebarPool.Get().GetComponent<Slider>();
        slider.minValue = min;
        slider.maxValue = max;
        slider.value = value;
        slider.gameObject.GetComponent<Lifebar>().target = transform;
        return slider;
    }
    //移除血条
    public void Remove(Slider slider)
    {
        LifebarPool.Release(slider.gameObject);
    }
    //刷新血条数值
    public void Refresh(Slider slider,float value)
    {
        slider.value = value;
    }

}
