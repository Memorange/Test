using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lifebar : MonoBehaviour
{
    public Transform target;
    //刷新血条位置
    private void Update() {
        if(target)
        {
            var targetScreen = Camera.main.WorldToScreenPoint(target.position+ new Vector3(0,0.8f,0));
            (transform as RectTransform).anchoredPosition = UIManager.Instance.ScreenToUI(targetScreen);
        }
    }
}
  