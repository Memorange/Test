using System.Collections;
using System.Collections.Generic;
using Cinemachine;
using UnityEngine;
using UnityStandardAssets.Cameras;


public class CameraControl : MonoBehaviour
{
    public CinemachineFreeLook _cam;
    private void Start() {
        EventManager.Instance.Add(EventType.CloseCamera,this,mdata=>
        {
            var data = mdata as EventDataCamera;
            _cam.enabled = data.isMove;
        });

    }
}
