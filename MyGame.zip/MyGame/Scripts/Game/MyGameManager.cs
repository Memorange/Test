using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyGameManager : SingleMono<MyGameManager>
{
    public PlayerInfo playerInfo;
    public PropConfig propConfig;
    // Start is called before the first frame update
    void Start()
    {
        UIManager.Instance.ShowPanel<MainUI>("MainPanel","MainPanel",()=>{
            Debug.Log("主页UI显示成功");
        });
        playerInfo =DataManager.Instance.LoadPlayerData();
        propConfig = ResLoad.instance.LoadAsset<PropConfig>("Config/PropConfig");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
