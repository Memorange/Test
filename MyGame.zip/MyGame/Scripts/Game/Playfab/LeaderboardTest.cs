using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeaderboardTest : MonoBehaviour
{
    public  int score;
    public string name;
    public void OnClick()
    {
        PlayfabManager.Instance.SendLeaderboard(score);
        
    }
    public void setName()
    {
        PlayfabManager.Instance.SetName(name);
    }
    
}
