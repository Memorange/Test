using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PlayFab;
using PlayFab.ClientModels;
using System;

public class PlayfabManager : SingleMono<PlayfabManager>
{
    public List<int> scoreList = new List<int>();
    public string playerName=string.Empty;
    // Start is called before the first frame update
    void Start()
    {
        Login();
    }

    public void SetName(string name)
    {
        var request = new UpdateUserTitleDisplayNameRequest()
        {
            DisplayName = name
        };
        PlayFabClientAPI.UpdateUserTitleDisplayName(request,OnTitleNameSuccess,OnError);
    }

    private void OnTitleNameSuccess(UpdateUserTitleDisplayNameResult obj)
    {
        playerName = obj.DisplayName;
        Debug.Log("name设置成功"+playerName);
    }

    public void GetLeaderboardData()
    {
        var request = new GetLeaderboardRequest()
        {
            StartPosition =0,
            StatisticName ="TestHighscore2",
            MaxResultsCount =10,

        };
        PlayFabClientAPI.GetLeaderboard(request,OnGetLeaderboardSuccess,OnError);
    }

    private void OnGetLeaderboardSuccess(GetLeaderboardResult obj)
    {
        scoreList.Clear();
        foreach (var info in obj.Leaderboard)
        {
            scoreList.Add(info.StatValue);
            Debug.Log("分数"+info.StatValue);
            Debug.Log("名次"+info.Position+1);
            
        }
    }
    #region 排行榜上传

    public void SendLeaderboard(int score)
    {
         var request = new UpdatePlayerStatisticsRequest()
         {
            Statistics = new List<StatisticUpdate>
            {
                new StatisticUpdate
                {
                    StatisticName ="TestHighscore2",
                    Value = score,
                }
            },
         };
         PlayFabClientAPI.UpdatePlayerStatistics(request,OnLeaderboardUpdateSuccess,OnError);
    }

    private void OnLeaderboardUpdateSuccess(UpdatePlayerStatisticsResult obj)
    {
        Debug.Log("数据上传成功");
        GetLeaderboardData();
    }
    #endregion

    #region 登录

    public void Login()
    {
        var request = new LoginWithCustomIDRequest()
        {
            //获取当前设备独立ID
            CustomId = SystemInfo.deviceUniqueIdentifier,
            CreateAccount = true,
            InfoRequestParameters = new GetPlayerCombinedInfoRequestParams
            {
                GetPlayerProfile = true
            }
        };
        PlayFabClientAPI.LoginWithCustomID(request,OnLoginSuccess,OnError);
    }
    private void OnLoginSuccess(LoginResult obj)
    {
        Debug.Log("成功登录");
        if(obj.InfoResultPayload.PlayerProfile !=null)
        {
            playerName = obj.InfoResultPayload.PlayerProfile.DisplayName;
        }
    }
    #endregion
    private void OnError(PlayFabError obj)
    {
        Debug.Log("登录失败");
        //生成错误信息
        Debug.Log(obj.GenerateErrorReport());
    }
}

    
