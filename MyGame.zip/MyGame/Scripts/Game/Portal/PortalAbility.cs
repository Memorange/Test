using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalAbility : MonoBehaviour
{
   private void OnCollisionEnter(Collision other) {
        var portal = other.gameObject.GetComponent<Portal>();
        if(portal)
        {
            Debug.Log("传送");
            transform.position = portal.next.point.transform.position;
        }
   }
}
