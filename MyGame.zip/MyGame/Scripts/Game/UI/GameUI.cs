using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class GameUI : UIBase
{
    public override void Init(UnityAction action = null)
    {
        base.Init(action);
        DefaultButton("ButtonBag",onEventBag);
        DefaultButton("ButtonBack",onEventBack);
    }
    private void onEventBack(BaseEventData arg0)
    {
        Hide(()=>
        {
            UIManager.Instance.ShowPanel<MainUI>("MainUI","MainPanel");
        });
    }

    private void onEventBag(BaseEventData arg0)
    {
        UIManager.Instance.ShowPanel<BagUI>("BagUI","BagUI");
    }

    public override void Show(UnityAction action = null)
    {
        base.Show(action);
    }
}
