using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class RankItem : MonoBehaviour
{
    public Image photo;
    public TMP_Text name;
    public TMP_Text LV;
    public TMP_Text Score;
}
