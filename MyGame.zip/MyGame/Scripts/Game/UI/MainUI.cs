using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;


public class MainUI : UIBase
{
    //private Image image;
    //private TMP_Text text;

    public override void Init(UnityAction action = null)
    {
        
        base.Init(action);
        
        DefaultButton("ButtonStart",onEventStart);
        DefaultButton("Title");
        showType = ShowType.Fade;
        //image = GetControl<Image>("StartButton");
        //text = GetControl<TMP_Text>("TitleText");
        //Debug.Log(text);
    }
    public override void Show(UnityAction action = null)
    {
        base.Show(action);
        //text.text="HI UI";
    }

    private void onEventStart(BaseEventData data)
    {
        Debug.Log("开始游戏");
        Hide(()=>
        {
            Debug.Log("显示UI");
            UIManager.Instance.ShowPanel<GameUI>("GamePanel","GamePanel");
        });
        //UIManager.Instance.ShowPanel<RankUI>("RankUI","RankUI");
        //UIManager.Instance.ShowPanel<BagUI>("BagUI","BagUI");
       
    }
}
