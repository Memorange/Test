using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[Serializable]

public struct RankData
{
    public Sprite photo;
    public string name;
    public int lv;
    public int score;
}


[CreateAssetMenu(fileName ="RankConfig",menuName ="Yea/RankConfig",order =1)]

public class RankConfig : ScriptableObject
{
   public List<RankData> rankList;

}
