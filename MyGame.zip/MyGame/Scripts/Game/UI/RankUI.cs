using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class RankUI : UIBase
{
    private RankConfig config;
    private Transform content;
    private Button close;
    public override void Init(UnityAction action = null)
    {
        base.Init(action);
        content = GetGameObject("Content").transform;
        close = GetControl<Button>("Btn_close");
        close.onClick.AddListener(()=>{
            Hide();
        });
    }

    List<RankData> BubbleSort(List<RankData> list)
    {
        if(list.Count<=1)
            return list;
        for(int i = 0 ; i<list.Count -1;i++)
        {
            for(int j=0;j<list.Count-1;j++)
            {
                if(list[j].lv.CompareTo(list[j+1].lv) < 0)
                {
                    var t = list[j];
                    list[j] = list[j+1];
                    list[j+1] = t;
                }
            }
        }
        return list;
    }
    public override void Show(UnityAction action = null)
    {
        base.Show(action);
        config = ResLoad.Instance.LoadAsset<RankConfig>("Config/RankConfig");
        var list = BubbleSort(config.rankList);
        foreach (var data in list)
        {   
            GameObject go = UIManager.Instance.LoadUIPrefab("RankChart",content);
            (go.transform as RectTransform).offsetMax= new Vector2(1376f,0f);
            RankItem ri = go.GetComponent<RankItem>();
            ri.photo.sprite = data.photo;
            ri.LV.text = string.Format("LV{0}",data.lv);
            ri.Score.text =data.score.ToString();
            ri.name.text = data.name; 
        }
    }
}
