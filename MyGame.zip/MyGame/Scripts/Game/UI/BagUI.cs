using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using UnityEngine.Pool;

public class BagUI : UIBase
{
    private RectTransform content;
    private ScrollRect scrollRect;
    //可视范围高
    private float viewPortH;
    private int itemCount;
    //一行显示2个
    private int col=2;
    //格子的间隔宽高
    private int itemW = 360;
    private int itemH = 350;
    //记录上次显示的索引范围
    private int oldMinIndex =-1;
    private int oldMaxIndex =-1;
    private Button close;
    private ObjectPool<GameObject> itemPool;

    //当前显示的格子对象
    private Dictionary<int,GameObject> nowShowItems = new Dictionary<int, GameObject>();
    public override void Init(UnityAction action = null)
    {
        base.Init(action);
        content = GetGameObject("Content").transform as RectTransform;
        scrollRect = GetControl<ScrollRect>("Scroll View");
        scrollRect.onValueChanged.AddListener(V2=>
        {
            UpdateItem();
        });
        viewPortH = (scrollRect.transform as RectTransform).sizeDelta.y;
        BagInfo.Instance.RefreshItemsInfo();
        itemCount = BagInfo.Instance.items.Count;
        //初始化Content的高
        content.sizeDelta = new Vector2(0,(itemCount/col +1) * itemH);

        itemPool = new ObjectPool<GameObject>(
            ()=>
            {
                var item = UIManager.Instance.LoadUIPrefab("BagItem",content,"Item");
                (item.transform as RectTransform).sizeDelta = new Vector2(300,300);
                item.GetComponent<Toggle>().group = content.gameObject.GetComponent<ToggleGroup>();
                return item;
            },
            go =>
            {
                go.SetActive(true);
            },
            go=>
            {
                go.GetComponent<Toggle>().isOn = false;
                go.SetActive(false);    
            },
            go=>{Destroy(go);}  
        );
        close = GetControl<Button>("Close");
        close.onClick.AddListener(()=>{
            Hide();
        });
        EventManager.Instance.Add(EventType.RefreshBag,this,data=>
        {
            Refresh();
        });
        
    }
    public override void Hide(UnityAction action = null)
    {
        base.Hide(action);
        EventManager.Instance.SendEvent(EventType.CloseCamera, new EventDataCamera(){isMove = true});
    }
    public void Refresh()
    {
        foreach (var data in nowShowItems)
        {
            itemPool.Release(data.Value);
        }
        oldMaxIndex =-1;
        oldMinIndex =-1;
        nowShowItems.Clear();
        BagInfo.Instance.RefreshItemsInfo();
        itemCount = BagInfo.Instance.items.Count;
        UpdateItem();
    }
    //更新格子的显示
    public void UpdateItem()
    {
        if(content.anchoredPosition.y<0)
        {
            return;
        }
        int minIndex = (int)(content.anchoredPosition.y / itemH ) * col;
        int maxIndex = (int)((content.anchoredPosition.y + viewPortH ) / itemH) * col + col - 1; 
        if(maxIndex >= itemCount)
        {
            maxIndex = itemCount - 1;
        }
        //上半部分
        for(int i = oldMinIndex; i< minIndex ; i++)
        {
            if(nowShowItems.ContainsKey(i))
            {
                itemPool.Release(nowShowItems[i]);
                //Destroy(nowShowItems[i]);
                nowShowItems.Remove(i);
            }
        }
        //下半部分
        for(int i = maxIndex + 1; i<= oldMaxIndex ; i++)
        {
            if(nowShowItems.ContainsKey(i))
            {
                itemPool.Release(nowShowItems[i]);
                //Destroy(nowShowItems[i]);
                nowShowItems.Remove(i);
            }
        }
        oldMaxIndex = maxIndex;
        oldMinIndex = minIndex;
        //创建指定范围内的格子
        for (int i = minIndex; i <= maxIndex; i++)
        {   
            if(nowShowItems.ContainsKey(i))
            {
                continue;
            }
            var item=itemPool.Get();
            //var item = UIManager.Instance.LoadUIPrefab("BagItem",content,"Item");
            //(item.transform as RectTransform).sizeDelta = new Vector2(350,450);
            item.transform.localPosition = new Vector3((i % col) * itemW + itemW/2 , (-i / col)* itemH - itemH/2 , 0);
            item.GetComponent<BagItem>().InitInfo(BagInfo.Instance.items[i]);
            nowShowItems.Add(i,item);
        }
    }
    public override void Show(UnityAction action = null)
    {
        base.Show(action);
        Refresh();
        EventManager.Instance.SendEvent(EventType.CloseCamera, new EventDataCamera(){isMove = false});
    }
}
