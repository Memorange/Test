using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BagItem : MonoBehaviour
{
    public TMP_Text numText;
    public TMP_Text idText;
    public Image iconImage;
    public GameObject selected;
    public ItemInfo itemInfo;

    public void InitInfo(ItemInfo info)
    {
        PropData propData = new PropData();
        foreach (var data in MyGameManager.Instance.propConfig.propList)
        {
            if(data.id == info.id)
                propData = data;
        }
        //读取Excel表格内容
        numText.text = info.num.ToString(); 
        idText.text = propData.name; 
        iconImage.sprite = propData.icon;
        itemInfo = info;

    }
    public void ShowSelected(bool isOn)
    {
        selected.SetActive(isOn);
    }   
    public void Sell()
    {
        Debug.Log("出售哪个道具"+itemInfo.id);
        MyGameManager.Instance.playerInfo.BagChangeItem(itemInfo.id,-itemInfo.num);
        EventManager.Instance.SendEvent(EventType.RefreshBag,null);
    }
    public void Buy()
    {
        Debug.Log("购买哪个道具"+itemInfo.id);
        MyGameManager.Instance.playerInfo.BagChangeItem(itemInfo.id,5);
        EventManager.Instance.SendEvent(EventType.RefreshBag,null);
    }
}
