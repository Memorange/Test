using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemInfo
{
    public int id;
    public int num;
}

public class BagInfo : Single<BagInfo>
{
   public List<ItemInfo> items = new List<ItemInfo>();
   
   public void RefreshItemsInfo()
   {
        var bagData = DataManager.Instance.LoadPlayerData().bag;
        items.Clear();
        // for (int i = 0; i < itemCount; i++)
        // {
        //     ItemInfo item = new ItemInfo();
        //     item.id = i;
        //     item.num = Random.Range(0,30);
        //     items.Add(item); 
        // }
        foreach (var data in bagData)
        {
            ItemInfo itemInfo = new ItemInfo();
            itemInfo.id = data.Key;
            itemInfo.num = data.Value;
            items.Add(itemInfo);
            
        }
   }
}
