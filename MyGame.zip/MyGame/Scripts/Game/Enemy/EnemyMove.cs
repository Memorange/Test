using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMove : MonoBehaviour
{
    public List<Transform> movePoints;
    private Vector3 target;
    private List<Vector3> targetList = new List<Vector3>();
    public float speed = 1f;    
    private void OnEnable() 
    {    
        foreach (var data in movePoints)
        {
            targetList.Add(data.position);
        }
        target = targetList[Random.Range(0,targetList.Count)];
    }
    private void Update() {
        float dis = Vector3.Distance(transform.position,target);
        if(dis < 0.8f)
        {
            //切换目标
            target = targetList[Random.Range(0,targetList.Count)];
        }
        transform.LookAt(target);
        transform.Translate(transform.forward * Time.deltaTime * speed);
    }
}
