using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class EnemyGenerate : MonoBehaviour
{
    public List<Transform> genPoints;
    public int enemyNum;
    public int survivalNum;
    // Start is called before the first frame update
    void Start()
    {
        //计时器
        Sequence seq = DOTween.Sequence();
        seq.SetDelay(2f);
        seq.SetLoops(-1);
        seq.AppendCallback(()=>
        {
            Debug.Log("生成敌人");
            if(survivalNum < enemyNum)
            {
                survivalNum++;
                var go = ResLoad.Instance.LoadPrefab("Prefabs/Enemy");
                go.transform.position = genPoints[Random.Range(0,genPoints.Count)].position;
            }
        });
    }
}
