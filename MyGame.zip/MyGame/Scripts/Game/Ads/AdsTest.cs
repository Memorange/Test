using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AdsTest : MonoBehaviour
{
    public AdsType type;
    public void show()
    {
        AdsManager.Instance.showAds(type);
    }
}
