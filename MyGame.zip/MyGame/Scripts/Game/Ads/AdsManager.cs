using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Advertisements;

public enum AdsType
{
    Reward = 0,
    Inter,
    Banner
}
public class AdsManager : SingleMono<AdsManager>,IUnityAdsInitializationListener,IUnityAdsLoadListener,IUnityAdsShowListener
{
    private string gameID = "";
    private string rewardID = "";
    private string interID = "";
    private string bannerID = "";
    // Start is called before the first frame update
    void Start()
    {
        switch(Application.platform)
        {
            case RuntimePlatform.Android:
                gameID = "5212070";
                rewardID = "Rewarded_Android";
                interID = "Interstitial_Android";
                bannerID = "Banner_Android";
                break;
            case RuntimePlatform.IPhonePlayer:
                gameID = "5212071";
                rewardID = "Rewarded_iOS";
                interID = "Interstitial_iOS";
                bannerID = "Banner_iOS";
                break;
            case RuntimePlatform.WindowsEditor:
                gameID = "5212070";
                rewardID = "Rewarded_Android";
                interID = "Interstitial_Android";
                bannerID = "Banner_Android";
                break;
        }
        Advertisement.Initialize(gameID,false,false,this);
    }
    public void showAds(AdsType type)
    {   
        string id = "";
        switch(type)
        {
            case AdsType.Reward:
                id = rewardID;
                break;
            case AdsType.Inter:
                id = interID;
                break;
            case AdsType.Banner:
                id = bannerID;
                break;
        }
        if(id==string.Empty)
        {
            Debug.LogError("Ads:id 出错");  
        }
        Advertisement.Show(id,this);
    }
    //初始化回调
    public void OnInitializationComplete()
    {
        Debug.Log("广告初始化成功");
        Advertisement.Load(rewardID,this);
        Advertisement.Load(interID,this);
        Advertisement.Load(bannerID,this);
    }

    public void OnInitializationFailed(UnityAdsInitializationError error, string message)
    {
        Debug.Log("广告初始化失败"+message);
    }
    //---------------------------------------------------------------
    //加载回调
    public void OnUnityAdsAdLoaded(string placementId)
    {
        Debug.Log("广告"+placementId+"加载成功");
    }

    public void OnUnityAdsFailedToLoad(string placementId, UnityAdsLoadError error, string message)
    {
        Debug.Log("广告"+placementId+"加载失败"+message);
    }
    //---------------------------------------------------------------
    //显示回调
    public void OnUnityAdsShowClick(string placementId)
    {
        
    }

    public void OnUnityAdsShowComplete(string placementId, UnityAdsShowCompletionState showCompletionState)
    {
        Debug.Log("广告显示结束" + placementId);
        //恢复游戏
        Time.timeScale=1;
    }

    public void OnUnityAdsShowFailure(string placementId, UnityAdsShowError error, string message)
    {
        Debug.Log("广告显示失败"+message);
    }

    public void OnUnityAdsShowStart(string placementId)
    {
        Debug.Log("广告显示成功" + placementId);
        //暂停游戏
        Time.timeScale=0;
    }

    
}
